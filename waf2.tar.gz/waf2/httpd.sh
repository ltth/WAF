pathmunge /usr/local/apache2/bin
